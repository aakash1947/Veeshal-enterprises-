# Veshaal Enterprise — VIP Mobile Number Marketplace

A mobile-first PHP 8.2 application for discovering, comparing and reserving premium Indian mobile numbers. The visual design and copy are original to Veshaal Enterprise; the workflow is informed by common VIP-number marketplace patterns and current official MNP guidance.

## Included

- Responsive storefront designed for high mobile traffic
- Number search by digits, start/end position, category, price, operator, state and digit root
- DOB suggestion engine with transparent birth-root, destiny-root and date-fragment ranking
- Product details, shortlist, guest checkout and order tracking
- Razorpay order creation and server-side signature verification
- Clearly labelled demo-payment mode for development
- Admin login, inventory CRUD, order status workflow and customer-visible updates
- SQLite first-run database plus MySQL schema
- CSRF protection, prepared SQL statements, escaped views, secure session cookies and password hashing
- Original navy, cobalt and mint visual identity
- Compliance-aware wording for operator eligibility, KYC, MNP and ownership rules

## Requirements

- PHP 8.2 or newer
- PDO SQLite (default) or PDO MySQL
- cURL extension for Razorpay
- Apache with `mod_rewrite`, or Nginx configured to route requests to `public/index.php`

## Quick start

1. Copy `.env.example` to `.env`.
2. Change `APP_URL`, `APP_KEY`, support details and the initial admin password.
3. From the project folder run:

   ```bash
   php -S 0.0.0.0:8080 -t public public/index.php
   ```

4. Open `http://localhost:8080`.
5. Open `/admin/login` with the email/password configured in `.env`.

The SQLite database and sample inventory are created automatically on first request.

## If the website opens without CSS

Version 2 automatically detects whether the application is running from a domain root or a subfolder. Make sure both stylesheet files exist:

- `public/assets/css/app.css`
- `public/assets/css/design-v2.css`

For shared hosting you can either point the domain document root to `public/` (recommended) or upload the complete extracted folder into `public_html`; the included root `index.php` and `.htaccess` support that common setup. If you use Nginx, configure the equivalent front-controller and static-assets rules.

After updating the files, clear the hosting/CDN cache and the mobile browser cache. The CSS links include a version query to prevent an older unstyled page from being reused.

## Production setup

### Web root

Point the domain document root to the `public/` folder. Do not expose `app/`, `config/`, `database/`, `storage/` or `.env` to the web.

## Design system

The storefront uses an original premium visual system for Veshaal Enterprise:

- Obsidian and deep-indigo foundations
- Royal violet primary actions
- Aqua-mint availability and trust signals
- Pearl-grey surfaces for long mobile browsing
- High-contrast number cards, 48px+ primary touch targets and a fixed mobile action bar
- Reduced-motion support and visible keyboard focus states

### MySQL

Set:

```dotenv
DB_DRIVER=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=veshaal_enterprise
DB_USER=your_user
DB_PASSWORD=your_password
```

The app applies `database/schema-mysql.sql` automatically. The database user needs schema-create permission on first run; reduce privileges afterwards if required.

### Razorpay

Set:

```dotenv
PAYMENT_GATEWAY=razorpay
RAZORPAY_KEY_ID=rzp_live_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```

The backend creates an order through Razorpay, launches hosted checkout, verifies the returned HMAC signature, marks the order paid, and moves the inventory from reserved to sold. Add a Razorpay webhook before production so delayed payment events can be reconciled independently of the browser callback.

### Recommended production hardening

- Replace the starter administrator credentials before the first public request.
- Serve HTTPS only and add HSTS, CSP and rate limiting at the web server or CDN.
- Add OTP login only through a compliant SMS vendor; never collect OTPs in support chat.
- Add Razorpay webhooks with idempotent event storage.
- Add a scheduled job to release unpaid reservations after a defined timeout.
- Encrypt backups and limit staff access to order contact data.
- Have an Indian telecom/regulatory lawyer review the business model, fulfilment route, terms, privacy notice and refund policy.
- Confirm current operator rules before advertising transfer, UPC or activation timelines.
- Do not market numerology as scientific or guarantee life outcomes.

## DOB matching method

1. Birth root: the birth day reduced to one digit.
2. Destiny root: all digits in `DDMMYYYY` summed and reduced to one digit.
3. Date fragments: `DDMMYYYY`, `DDMM`, `MMDD`, `YYYY`, `YY` and `DD` are searched in each available number.
4. Ranking: exact destiny/birth-root matches, supportive roots, matching date fragments and recall score produce the displayed percentage.

This feature is a cultural/personal preference tool and not a scientifically validated prediction.

## Order stages

- `pending_payment`
- `verification`
- `eligibility_issue`
- `documents_ready`
- `porting`
- `activated`
- `cancelled`
- `refunded`

## Important compliance note

### Vercel deployment

The repository includes a Vercel serverless entry point and routing config.
Vercel uses the bundled PHP runtime and an ephemeral SQLite database under
`/tmp`, which is suitable for the live demo and catalogue browsing. For
production orders and admin changes, configure a persistent MySQL database
through the `DB_*` environment variables.

The source deliberately describes checkout as a reservation rather than guaranteeing transfer. Current telecom rules and operator processes determine whether ownership change, MNP, KYC and activation are permitted. The authorised operator and official TRAI/DoT guidance always prevail.
