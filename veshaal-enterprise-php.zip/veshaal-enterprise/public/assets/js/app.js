(() => {
  'use strict';

  const menuToggle = document.querySelector('[data-menu-toggle]');
  const mobileMenu = document.querySelector('[data-mobile-menu]');
  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener('click', () => {
      const open = mobileMenu.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(open));
    });
  }

  document.querySelectorAll('[data-search-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('[data-search-tab]').forEach((item) => item.classList.remove('active'));
      document.querySelectorAll('[data-search-panel]').forEach((item) => item.classList.remove('active'));
      tab.classList.add('active');
      const panel = document.querySelector(`[data-search-panel="${tab.dataset.searchTab}"]`);
      if (panel) panel.classList.add('active');
    });
  });

  const filters = document.querySelector('[data-filter-panel]');
  document.querySelector('[data-filter-open]')?.addEventListener('click', () => filters?.classList.add('open'));
  document.querySelector('[data-filter-close]')?.addEventListener('click', () => filters?.classList.remove('open'));

  const inventoryForm = document.querySelector('[data-inventory-form]');
  document.querySelectorAll('[data-edit-inventory]').forEach((button) => {
    button.addEventListener('click', () => {
      if (!inventoryForm) return;
      const row = JSON.parse(button.dataset.editInventory || '{}');
      Object.entries(row).forEach(([key, value]) => {
        const field = inventoryForm.elements.namedItem(key);
        if (!field) return;
        if (field.type === 'checkbox') field.checked = Number(value) === 1;
        else field.value = value ?? '';
      });
      inventoryForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });

  const payButton = document.getElementById('razorpay-pay');
  if (payButton && window.VESHAAL_PAYMENT) {
    payButton.addEventListener('click', () => {
      const config = window.VESHAAL_PAYMENT;
      const error = document.getElementById('payment-error');
      if (typeof window.Razorpay !== 'function') {
        if (error) error.textContent = 'Payment service did not load. Please check your connection and retry.';
        return;
      }
      const checkout = new window.Razorpay({
        key: config.key,
        amount: config.amount,
        currency: config.currency,
        name: config.name,
        description: config.description,
        order_id: config.order_id,
        prefill: config.prefill,
        theme: { color: '#315cff' },
        handler: async (response) => {
          payButton.disabled = true;
          payButton.textContent = 'Verifying payment…';
          const body = new URLSearchParams({
            _token: config.csrf,
            order_number: config.order_number,
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature
          });
          try {
            const result = await fetch(config.verify, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
            const payload = await result.json();
            if (!result.ok || !payload.ok) throw new Error(payload.message || 'Verification failed.');
            window.location.href = payload.redirect;
          } catch (exception) {
            if (error) error.textContent = exception.message;
            payButton.disabled = false;
            payButton.textContent = 'Retry secure payment';
          }
        }
      });
      checkout.on('payment.failed', (response) => {
        if (error) error.textContent = response.error?.description || 'Payment was not completed.';
      });
      checkout.open();
    });
  }

  window.setTimeout(() => {
    document.querySelectorAll('.flash').forEach((flash) => flash.remove());
  }, 5000);
})();

