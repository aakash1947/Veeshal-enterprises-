<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('X-Frame-Options: SAMEORIGIN');

use Veshaal\Controllers\AdminController;
use Veshaal\Controllers\ApiController;
use Veshaal\Controllers\SiteController;

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = base_path();
if ($base !== '' && str_starts_with($path, $base)) {
    $path = substr($path, strlen($base)) ?: '/';
}
$path = '/' . trim($path, '/');
if ($path !== '/') {
    $path = rtrim($path, '/');
}

$site = new SiteController();
$api = new ApiController();
$admin = new AdminController();

$routes = [
    'GET' => [
        '/' => [$site, 'home'],
        '/numbers' => [$site, 'numbers'],
        '/numerology' => [$site, 'numerology'],
        '/cart' => [$site, 'cart'],
        '/checkout' => [$site, 'checkout'],
        '/track-order' => [$site, 'track'],
        '/how-it-works' => [$site, 'howItWorks'],
        '/faq' => [$site, 'faq'],
        '/contact' => [$site, 'contact'],
        '/legal' => [$site, 'legal'],
        '/admin' => [$admin, 'dashboard'],
        '/admin/login' => [$admin, 'login'],
        '/admin/inventory' => [$admin, 'inventory'],
        '/admin/orders' => [$admin, 'orders'],
        '/api/numbers' => [$api, 'numbers'],
        '/api/dob-suggestions' => [$api, 'dobSuggestions'],
    ],
    'POST' => [
        '/checkout' => [$site, 'placeOrder'],
        '/track-order' => [$site, 'track'],
        '/contact' => [$site, 'contact'],
        '/admin/login' => [$admin, 'authenticate'],
        '/admin/logout' => [$admin, 'logout'],
        '/admin/inventory/save' => [$admin, 'saveInventory'],
        '/admin/inventory/delete' => [$admin, 'deleteInventory'],
        '/admin/orders/update' => [$admin, 'updateOrder'],
        '/api/payment/create' => [$api, 'createPayment'],
        '/api/payment/verify' => [$api, 'verifyPayment'],
    ],
];

if (preg_match('#^/number/(\d{10})$#', $path, $matches)) {
    $site->numberDetail($matches[1]);
    exit;
}
if (preg_match('#^/order/([A-Z0-9-]+)$#', $path, $matches)) {
    $site->orderSuccess($matches[1]);
    exit;
}
if (preg_match('#^/pay/([A-Z0-9-]+)$#', $path, $matches)) {
    $site->payment($matches[1]);
    exit;
}

$handler = $routes[$method][$path] ?? null;
if (!$handler) {
    http_response_code(404);
    view('pages/404', ['title' => 'Page not found']);
    exit;
}

call_user_func($handler);
