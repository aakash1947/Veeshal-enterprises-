<?php
return [
    'name' => env('APP_NAME', 'Veshaal Enterprise'),
    'env' => env('APP_ENV', 'local'),
    'debug' => env('APP_DEBUG', false),
    'url' => env('APP_URL', ''),
    'key' => env('APP_KEY', 'development-only-key-change-it'),
    'whatsapp' => env('WHATSAPP_NUMBER', '919999999999'),
    'support_phone' => env('SUPPORT_PHONE', '+91 99999 99999'),
    'support_email' => env('SUPPORT_EMAIL', 'hello@veshaal.example'),
    'payment_gateway' => env('PAYMENT_GATEWAY', 'demo'),
];

