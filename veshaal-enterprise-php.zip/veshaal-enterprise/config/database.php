<?php
$defaultSqlitePath = env('VERCEL') ? '/tmp/veshaal.sqlite' : 'storage/veshaal.sqlite';

return [
    'driver' => env('DB_DRIVER', 'sqlite'),
    'database' => env('DB_DATABASE', $defaultSqlitePath),
    'host' => env('DB_HOST', '127.0.0.1'),
    'port' => env('DB_PORT', '3306'),
    'name' => env('DB_NAME', 'veshaal_enterprise'),
    'user' => env('DB_USER', 'root'),
    'password' => env('DB_PASSWORD', ''),
];
