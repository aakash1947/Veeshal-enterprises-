<?php
declare(strict_types=1);

// Vercel serverless entry point. The application router remains in public/.
require dirname(__DIR__) . '/public/index.php';
