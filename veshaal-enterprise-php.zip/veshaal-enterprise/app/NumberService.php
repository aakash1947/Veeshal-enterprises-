<?php
declare(strict_types=1);

namespace Veshaal;

use DateTimeImmutable;

final class NumberService
{
    public function search(array $filters = [], int $limit = 60): array
    {
        $where = ["status = 'available'"];
        $params = [];

        $query = digits((string) ($filters['q'] ?? ''));
        $mode = (string) ($filters['match'] ?? 'any');
        if ($query !== '') {
            if ($mode === 'start') {
                $where[] = 'mobile_number LIKE ?';
                $params[] = $query . '%';
            } elseif ($mode === 'end') {
                $where[] = 'mobile_number LIKE ?';
                $params[] = '%' . $query;
            } elseif ($mode === 'exact' && strlen($query) === 10) {
                $where[] = 'mobile_number = ?';
                $params[] = $query;
            } else {
                $where[] = 'mobile_number LIKE ?';
                $params[] = '%' . $query . '%';
            }
        }

        foreach (['category', 'operator', 'state'] as $field) {
            $value = trim((string) ($filters[$field] ?? ''));
            if ($value !== '' && !in_array($value, ['All', 'Any', 'Pan India'], true)) {
                $where[] = $field . ' = ?';
                $params[] = $value;
            }
        }
        if (($filters['min_price'] ?? '') !== '') {
            $where[] = 'price >= ?';
            $params[] = max(0, (int) $filters['min_price']);
        }
        if (($filters['max_price'] ?? '') !== '') {
            $where[] = 'price <= ?';
            $params[] = max(0, (int) $filters['max_price']);
        }

        $sort = match ((string) ($filters['sort'] ?? 'featured')) {
            'price_low' => 'price ASC',
            'price_high' => 'price DESC',
            'newest' => 'added_at DESC',
            default => 'featured DESC, added_at DESC, price ASC',
        };

        $sql = 'SELECT * FROM numbers WHERE ' . implode(' AND ', $where) . ' ORDER BY ' . $sort . ' LIMIT ' . max(1, min($limit, 200));
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $root = (int) ($filters['root'] ?? 0);
        $rows = array_map([$this, 'decorate'], $rows);
        if ($root >= 1 && $root <= 9) {
            $rows = array_values(array_filter($rows, static fn(array $row): bool => $row['root'] === $root));
        }
        return $rows;
    }

    public function findByMobile(string $mobile): ?array
    {
        $stmt = db()->prepare('SELECT * FROM numbers WHERE mobile_number = ? LIMIT 1');
        $stmt->execute([digits($mobile)]);
        $row = $stmt->fetch();
        return $row ? $this->decorate($row) : null;
    }

    public function findById(int $id): ?array
    {
        $stmt = db()->prepare('SELECT * FROM numbers WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? $this->decorate($row) : null;
    }

    public function suggestionsForDob(string $dob, array $filters = []): array
    {
        $date = DateTimeImmutable::createFromFormat('Y-m-d', $dob);
        $errors = DateTimeImmutable::getLastErrors();
        if (!$date || ($errors !== false && ($errors['warning_count'] || $errors['error_count']))) {
            return ['error' => 'Please enter a valid date of birth.'];
        }
        if ($date > new DateTimeImmutable('today') || $date < new DateTimeImmutable('1900-01-01')) {
            return ['error' => 'Please enter a realistic date of birth.'];
        }

        $birth = digital_root((int) $date->format('d'));
        $destiny = digital_root(array_sum(array_map('intval', str_split($date->format('dmY')))));
        $friendly = [
            1 => [1, 3, 5, 9], 2 => [2, 4, 6], 3 => [1, 3, 6, 9],
            4 => [2, 4, 7, 8], 5 => [1, 5, 6], 6 => [2, 3, 6, 9],
            7 => [4, 5, 7], 8 => [2, 4, 8], 9 => [1, 3, 6, 9],
        ];
        $preferredRoots = array_values(array_unique(array_merge([$destiny, $birth], $friendly[$destiny] ?? [])));
        $fragments = array_values(array_unique([
            $date->format('dmY'), $date->format('dm'), $date->format('md'),
            $date->format('Y'), $date->format('y'), $date->format('d'),
        ]));

        $rows = $this->search($filters, 200);
        foreach ($rows as &$row) {
            $rank = 0;
            $reasons = [];
            if ($row['root'] === $destiny) {
                $rank += 70;
                $reasons[] = 'Matches destiny root ' . $destiny;
            } elseif ($row['root'] === $birth) {
                $rank += 55;
                $reasons[] = 'Matches birth root ' . $birth;
            } elseif (in_array($row['root'], $preferredRoots, true)) {
                $rank += 30;
                $reasons[] = 'Supportive root ' . $row['root'];
            }
            foreach ($fragments as $index => $fragment) {
                if (strlen($fragment) >= 2 && str_contains($row['mobile_number'], $fragment)) {
                    $rank += max(8, 45 - ($index * 7));
                    $reasons[] = 'Contains ' . $fragment;
                    break;
                }
            }
            $rank += $row['pattern_score'] * 2;
            $row['match_score'] = min(99, $rank);
            $row['match_reasons'] = $reasons ?: ['Strong memorable pattern'];
        }
        unset($row);
        usort($rows, static fn(array $a, array $b): int => $b['match_score'] <=> $a['match_score']);

        return [
            'dob' => $date->format('d M Y'),
            'birth_root' => $birth,
            'destiny_root' => $destiny,
            'preferred_roots' => $preferredRoots,
            'numbers' => array_slice($rows, 0, 18),
        ];
    }

    public function filterOptions(): array
    {
        $options = [];
        foreach (['category', 'operator', 'state'] as $field) {
            $stmt = db()->query("SELECT DISTINCT {$field} FROM numbers WHERE {$field} IS NOT NULL AND {$field} != '' ORDER BY {$field}");
            $options[$field . 's'] = array_column($stmt->fetchAll(), $field);
        }
        return $options;
    }

    public function decorate(array $row): array
    {
        $sum = number_sum((string) $row['mobile_number']);
        $row['sum'] = $sum;
        $row['root'] = digital_root($sum);
        $row['pattern_score'] = pattern_score((string) $row['mobile_number']);
        $row['formatted'] = format_mobile((string) $row['mobile_number']);
        return $row;
    }
}

