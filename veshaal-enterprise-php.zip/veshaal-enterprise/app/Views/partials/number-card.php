<article class="number-card">
  <div class="number-card-top">
    <span class="status-dot" title="Available"></span>
    <span class="card-label"><?= e($number['category']) ?></span>
    <?php if (!empty($number['featured'])): ?><span class="verified-badge">Verified</span><?php endif; ?>
  </div>
  <a class="number-display" href="<?= e(url('number/' . $number['mobile_number'])) ?>"><?= e($number['formatted']) ?></a>
  <div class="number-metrics">
    <span>Sum <strong><?= e($number['sum']) ?></strong></span>
    <span>Root <strong><?= e($number['root']) ?></strong></span>
    <span>Recall <strong><?= e($number['pattern_score']) ?>/10</strong></span>
  </div>
  <?php if (isset($number['match_score'])): ?>
    <div class="match-bar"><span style="width:<?= (int) $number['match_score'] ?>%"></span></div>
    <p class="match-copy"><strong><?= (int) $number['match_score'] ?>% match</strong> · <?= e(implode(' · ', array_slice($number['match_reasons'], 0, 2))) ?></p>
  <?php endif; ?>
  <div class="number-location"><span><?= e($number['operator']) ?></span><span><?= e($number['city'] ?: $number['state']) ?></span></div>
  <div class="number-card-footer">
    <div><small>Reservation price</small><strong><?= e(money($number['price'])) ?></strong></div>
    <a class="button button-sm" href="<?= e(url('checkout?number=' . $number['id'])) ?>">Reserve now</a>
  </div>
  <a class="shortlist-link" href="<?= e(url('cart?add=' . $number['id'])) ?>">♡ Add to shortlist</a>
</article>

