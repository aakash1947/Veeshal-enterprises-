<section class="section"><div class="container narrow"><div class="empty-state"><span>404</span><h1>That page is not in our catalogue.</h1><p>The link may be old, or the number may no longer be listed.</p><a class="button" href="<?= e(url('numbers')) ?>">Browse available numbers</a></div></div></section>

