<section class="page-hero compact"><div class="container"><span class="eyebrow">Live catalogue</span><h1>Choose a number that fits you.</h1><p>Use simple filters on mobile, or open advanced options for a precise match.</p></div></section>
<section class="catalog-section"><div class="container catalog-layout">
  <aside class="filters" data-filter-panel>
    <div class="filter-title"><h2>Filters</h2><button type="button" data-filter-close>Close</button></div>
    <form action="<?= e(url('numbers')) ?>" method="get">
      <label>Wanted digits<input name="q" inputmode="numeric" maxlength="10" value="<?= e($filters['q'] ?? '') ?>" placeholder="e.g. 786, 9999"></label>
      <label>Match position<select name="match"><option value="any">Anywhere</option><option value="start" <?= ($filters['match'] ?? '') === 'start' ? 'selected' : '' ?>>Starts with</option><option value="end" <?= ($filters['match'] ?? '') === 'end' ? 'selected' : '' ?>>Ends with</option><option value="exact" <?= ($filters['match'] ?? '') === 'exact' ? 'selected' : '' ?>>Exact number</option></select></label>
      <label>Category<select name="category"><option value="">All categories</option><?php foreach ($categories as $option): ?><option <?= ($filters['category'] ?? '') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></label>
      <div class="field-pair"><label>Min price<input type="number" name="min_price" value="<?= e($filters['min_price'] ?? '') ?>" placeholder="1500"></label><label>Max price<input type="number" name="max_price" value="<?= e($filters['max_price'] ?? '') ?>" placeholder="25000"></label></div>
      <label>Operator<select name="operator"><option value="">Any operator</option><?php foreach ($operators as $option): ?><option <?= ($filters['operator'] ?? '') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></label>
      <label>State<select name="state"><option value="">Pan India</option><?php foreach ($states as $option): ?><option <?= ($filters['state'] ?? '') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></label>
      <label>Digit total root<select name="root"><option value="">Any root</option><?php for ($i=1;$i<=9;$i++): ?><option value="<?= $i ?>" <?= (int)($filters['root'] ?? 0) === $i ? 'selected' : '' ?>>Root <?= $i ?></option><?php endfor; ?></select></label>
      <button class="button button-block">Apply filters</button><a class="reset-link" href="<?= e(url('numbers')) ?>">Reset all filters</a>
    </form>
  </aside>
  <div class="catalog-main">
    <div class="catalog-toolbar"><div><button class="filter-open" type="button" data-filter-open>☷ Filters</button><strong><?= count($numbers) ?> numbers</strong></div><form><input type="hidden" name="q" value="<?= e($filters['q'] ?? '') ?>"><select name="sort" onchange="this.form.submit()"><option value="featured">Recommended</option><option value="newest" <?= ($filters['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Newest</option><option value="price_low" <?= ($filters['sort'] ?? '') === 'price_low' ? 'selected' : '' ?>>Price: low to high</option><option value="price_high" <?= ($filters['sort'] ?? '') === 'price_high' ? 'selected' : '' ?>>Price: high to low</option></select></form></div>
    <?php if ($numbers): ?><div class="number-grid"><?php foreach ($numbers as $number) require BASE_PATH . '/app/Views/partials/number-card.php'; ?></div>
    <?php else: ?><div class="empty-state"><span>⌕</span><h2>No exact matches yet</h2><p>Try fewer digits, a wider budget or another category.</p><a class="button" href="<?= e(url('numbers')) ?>">Clear filters</a></div><?php endif; ?>
  </div>
</div></section>

