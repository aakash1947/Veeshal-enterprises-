<section class="hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">Memorable numbers. Smarter search.</span>
      <h1>Find a number people <em>remember.</em></h1>
      <p>Search premium mobile numbers by pattern, price, operator, location or your date of birth—then reserve with a clear, trackable process.</p>
      <form class="hero-search" action="<?= e(url('numbers')) ?>" method="get">
        <label class="sr-only" for="hero-q">Search mobile number digits</label>
        <input id="hero-q" name="q" inputmode="numeric" maxlength="10" placeholder="Try 9999, 786 or your birth year">
        <button class="button" type="submit">Search numbers</button>
      </form>
      <div class="hero-trust"><span>✓ Curated inventory</span><span>✓ Secure checkout-ready</span><span>✓ Human support</span></div>
    </div>
    <div class="hero-product" aria-label="Featured premium number example">
      <div class="signal-row"><span>VESHAAL SELECT</span><span class="live-dot">Available</span></div>
      <div class="hero-number"><b>98</b> 98 98 <b>1212</b></div>
      <div class="hero-tags"><span>Repeating pair</span><span>Root 3</span><span>Recall 9/10</span></div>
      <div class="hero-price"><div><small>Starting from</small><strong>₹1,500</strong></div><a href="<?= e(url('numbers')) ?>">Explore →</a></div>
      <div class="orbit orbit-one">7</div><div class="orbit orbit-two">9</div><div class="orbit orbit-three">3</div>
    </div>
  </div>
</section>

<section class="mobile-quick-panel">
  <div class="container">
    <div class="quick-tabs" role="tablist"><button class="active" type="button" data-search-tab="pattern">Pattern</button><button type="button" data-search-tab="dob">Date of birth</button><button type="button" data-search-tab="price">Budget</button></div>
    <div class="quick-tab-content active" data-search-panel="pattern"><form action="<?= e(url('numbers')) ?>"><input name="q" inputmode="numeric" placeholder="Digits you want"><select name="match"><option value="any">Anywhere</option><option value="start">Starts with</option><option value="end">Ends with</option></select><button class="button">Show matches</button></form></div>
    <div class="quick-tab-content" data-search-panel="dob"><form action="<?= e(url('numerology')) ?>"><input type="date" name="dob" required><button class="button">Find DOB matches</button></form></div>
    <div class="quick-tab-content" data-search-panel="price"><form action="<?= e(url('numbers')) ?>"><select name="max_price"><option value="5000">Under ₹5,000</option><option value="10000">Under ₹10,000</option><option value="25000">Under ₹25,000</option><option value="50000">Under ₹50,000</option></select><button class="button">Browse budget</button></form></div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-head"><div><span class="eyebrow">Fresh inventory</span><h2>New numbers worth seeing</h2></div><a href="<?= e(url('numbers?sort=newest')) ?>">View all →</a></div>
    <div class="number-grid"><?php foreach ($newNumbers as $number) require BASE_PATH . '/app/Views/partials/number-card.php'; ?></div>
  </div>
</section>

<section class="section dob-feature">
  <div class="container dob-grid">
    <div class="dob-art"><span class="dob-ring ring-a"></span><span class="dob-ring ring-b"></span><div class="dob-date"><small>YOUR DATE</small><strong>14 · 02 · 1995</strong><span>Birth root 5 · Destiny root 4</span></div></div>
    <div><span class="eyebrow">Personal number discovery</span><h2>Turn your birth date into a smarter shortlist.</h2><p>Our finder calculates birth and destiny roots, checks date fragments against available numbers, and ranks memorable options. Numerology is presented as a preference tool—not a scientific or guaranteed prediction.</p><a class="button" href="<?= e(url('numerology')) ?>">Try the DOB finder</a></div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-head"><div><span class="eyebrow">Veshaal Select</span><h2>Premium patterns</h2></div><a href="<?= e(url('numbers?sort=price_high')) ?>">See premium →</a></div>
    <div class="number-grid"><?php foreach ($featured as $number) require BASE_PATH . '/app/Views/partials/number-card.php'; ?></div>
  </div>
</section>

<section class="section pattern-section">
  <div class="container"><div class="section-head"><div><span class="eyebrow">Browse your way</span><h2>Popular number styles</h2></div></div>
    <div class="pattern-grid">
      <?php foreach ([['Mirror','Reads beautifully both ways','9112191121'],['Repeating pairs','Built for easy recall','9898981212'],['786 series','A preferred personal sequence','7867869090'],['Counting','Rhythmic ascending digits','8888123456'],['Tetra digits','Four-in-a-row impact','9090907777'],['Birth year','Carry a meaningful year','7000019477']] as $p): ?>
      <a href="<?= e(url('numbers?category=' . urlencode($p[0]))) ?>"><small><?= e($p[1]) ?></small><strong><?= e(format_mobile($p[2])) ?></strong><span><?= e($p[0]) ?> →</span></a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section journey-section">
  <div class="container"><div class="section-head"><div><span class="eyebrow">Clear from day one</span><h2>Your reservation journey</h2></div></div>
    <div class="journey-grid">
      <article><span>01</span><h3>Discover</h3><p>Search by digits, category, budget, operator, state or DOB preference.</p></article>
      <article><span>02</span><h3>Reserve securely</h3><p>Enter your details, review eligibility terms and complete payment.</p></article>
      <article><span>03</span><h3>Verify eligibility</h3><p>Our team confirms inventory, operator conditions and required documentation.</p></article>
      <article><span>04</span><h3>Complete with operator</h3><p>Finish operator KYC/MNP steps where legally permitted and track every milestone.</p></article>
    </div>
    <div class="center"><a class="button button-outline" href="<?= e(url('how-it-works')) ?>">Read the complete process</a></div>
  </div>
</section>

<section class="section cta-section"><div class="container cta-panel"><div><span class="eyebrow">Need a human opinion?</span><h2>Tell us the pattern you have in mind.</h2><p>Our advisor can help turn a birthday, business name, repeated digit or budget into a focused shortlist.</p></div><a class="button button-light" href="<?= e(url('contact')) ?>">Talk to an advisor</a></div></section>

