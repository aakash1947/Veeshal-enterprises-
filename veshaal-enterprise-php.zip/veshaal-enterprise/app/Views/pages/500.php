<section class="section"><div class="container narrow"><div class="empty-state"><span>!</span><h1>We could not load this page.</h1><p>Please try again. If the problem continues, contact Veshaal Enterprise support.</p><a class="button" href="<?= e(url()) ?>">Return home</a></div></div></section>

