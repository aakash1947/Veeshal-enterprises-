<section class="page-hero compact"><div class="container"><span class="eyebrow">Answers before checkout</span><h1>Frequently asked questions</h1></div></section><section class="section"><div class="container narrow-wide faq-list">
<?php foreach ([
['What does the reservation price include?','It covers the listed Veshaal Enterprise inventory reservation/service. Operator SIM, recharge, postpaid plan, KYC or other operator charges are separate unless the checkout explicitly says otherwise.'],
['Is a VIP number guaranteed to activate?','No marketplace should promise activation before the authorised operator checks eligibility and completes KYC. We recheck inventory and guide the process, but operator and regulatory decisions control the final outcome.'],
['Can I choose Airtel, Jio, Vi or BSNL?','You can state a preference at checkout. Actual availability and activation depend on the chosen operator, circle, number status and current rules.'],
['How does the DOB finder work?','It calculates a birth root from the birth day and a destiny root from all DOB digits. It then ranks available numbers by root match, DOB fragments and memorability. It is a preference tool, not a scientific prediction.'],
['Is my date of birth stored?','The catalogue finder uses the date only for the current request and does not save it in the database. Checkout stores only the details shown in the order form.'],
['What information should I never share?','Never share OTPs, UPI PINs, card PINs, banking passwords or remote-screen access with marketplace staff. Operator KYC should happen only through the authorised process.'],
['What if the number cannot be fulfilled?','The order follows the published cancellation and refund terms. Eligibility failures, inventory discrepancies and operator restrictions are reviewed and recorded in the order status.'],
['How do I track my order?','Open Track Order and enter the Veshaal order reference plus the registered mobile number. You will see the latest stage and any advisor note.']
] as $faq): ?><details><summary><?= e($faq[0]) ?><span>+</span></summary><p><?= e($faq[1]) ?></p></details><?php endforeach; ?>
</div></section>

