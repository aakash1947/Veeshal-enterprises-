<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($title ?? 'Admin') ?> | Veshaal Enterprise</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>?v=2.0.0">
  <link rel="stylesheet" href="<?= e(asset('css/design-v2.css')) ?>?v=2.0.0">
</head>
<body class="admin-body">
  <?php if (!empty($_SESSION['admin_id'])): ?>
  <header class="admin-header"><a class="brand" href="<?= e(url('admin')) ?>"><span class="brand-mark">VE</span><strong>Admin</strong></a><nav><a href="<?= e(url('admin')) ?>">Dashboard</a><a href="<?= e(url('admin/inventory')) ?>">Inventory</a><a href="<?= e(url('admin/orders')) ?>">Orders</a><form method="post" action="<?= e(url('admin/logout')) ?>"><?= csrf_field() ?><button class="text-button">Log out</button></form></nav></header>
  <?php endif; ?>
  <?php if ($message = flash('success')): ?><div class="flash flash-success"><?= e($message) ?></div><?php endif; ?>
  <?php if ($message = flash('error')): ?><div class="flash flash-error"><?= e($message) ?></div><?php endif; ?>
  <main class="admin-main"><?= $content ?></main>
  <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
