<?php
$appName = (string) config('app.name');
$pageTitle = isset($title) ? $title . ' | ' . $appName : $appName;
$cartCount = count($_SESSION['cart'] ?? []);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0c1020">
  <meta name="description" content="Discover, compare and reserve memorable premium mobile numbers with Veshaal Enterprise.">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($pageTitle) ?></title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>?v=2.0.0">
  <link rel="stylesheet" href="<?= e(asset('css/design-v2.css')) ?>?v=2.0.0">
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>
  <div class="notice-bar">Operator approval & KYC required · Inventory verified before fulfilment</div>
  <header class="site-header">
    <div class="container nav-wrap">
      <a class="brand" href="<?= e(url()) ?>" aria-label="Veshaal Enterprise home">
        <span class="brand-mark">VE</span>
        <span><strong>Veshaal</strong><small>Enterprise</small></span>
      </a>
      <nav class="desktop-nav" aria-label="Main navigation">
        <a href="<?= e(url('numbers')) ?>">Explore numbers</a>
        <a href="<?= e(url('numerology')) ?>">DOB finder</a>
        <a href="<?= e(url('how-it-works')) ?>">How it works</a>
        <a href="<?= e(url('track-order')) ?>">Track order</a>
      </nav>
      <div class="nav-actions">
        <a class="icon-link" href="<?= e(url('cart')) ?>" aria-label="Shortlist">♡<span class="count-badge"><?= $cartCount ?></span></a>
        <a class="button button-sm" href="<?= e(url('numbers')) ?>">Find my number</a>
        <button class="menu-toggle" type="button" data-menu-toggle aria-expanded="false" aria-controls="mobile-menu">Menu</button>
      </div>
    </div>
    <nav class="mobile-menu" id="mobile-menu" data-mobile-menu aria-label="Mobile navigation">
      <a href="<?= e(url('numbers')) ?>">Explore numbers</a>
      <a href="<?= e(url('numerology')) ?>">DOB number finder</a>
      <a href="<?= e(url('how-it-works')) ?>">How it works</a>
      <a href="<?= e(url('track-order')) ?>">Track order</a>
      <a href="<?= e(url('contact')) ?>">Talk to an advisor</a>
    </nav>
  </header>

  <?php if ($message = flash('success')): ?><div class="flash flash-success" role="status"><?= e($message) ?></div><?php endif; ?>
  <?php if ($message = flash('error')): ?><div class="flash flash-error" role="alert"><?= e($message) ?></div><?php endif; ?>

  <main id="main"><?= $content ?></main>

  <footer class="site-footer">
    <div class="container footer-grid">
      <div>
        <a class="brand brand-light" href="<?= e(url()) ?>"><span class="brand-mark">VE</span><span><strong>Veshaal</strong><small>Enterprise</small></span></a>
        <p>A mobile-first marketplace experience for discovering and reserving memorable Indian mobile numbers.</p>
        <p class="fine-print">Number availability, ownership eligibility, UPC generation, KYC and activation remain subject to the relevant telecom operator and current regulations.</p>
      </div>
      <div><h3>Discover</h3><a href="<?= e(url('numbers')) ?>">All numbers</a><a href="<?= e(url('numerology')) ?>">DOB finder</a><a href="<?= e(url('cart')) ?>">Shortlist</a></div>
      <div><h3>Support</h3><a href="<?= e(url('how-it-works')) ?>">Buying journey</a><a href="<?= e(url('track-order')) ?>">Track order</a><a href="<?= e(url('faq')) ?>">FAQs</a><a href="<?= e(url('contact')) ?>">Contact</a></div>
      <div><h3>Legal</h3><a href="<?= e(url('legal#terms')) ?>">Terms</a><a href="<?= e(url('legal#privacy')) ?>">Privacy</a><a href="<?= e(url('legal#refunds')) ?>">Refund policy</a><a href="https://trai.gov.in/faqcategory/mobile-number-portability" rel="noopener" target="_blank">TRAI MNP guide</a></div>
    </div>
    <div class="container footer-bottom"><span>© <?= date('Y') ?> Veshaal Enterprise</span><span>Built for fast mobile shopping</span></div>
  </footer>

  <nav class="bottom-nav" aria-label="Quick navigation">
    <a href="<?= e(url()) ?>"><span>⌂</span>Home</a>
    <a href="<?= e(url('numbers')) ?>"><span>⌕</span>Numbers</a>
    <a class="bottom-nav-featured" href="<?= e(url('numerology')) ?>"><span>✦</span>DOB finder</a>
    <a href="<?= e(url('cart')) ?>"><span>♡</span>Shortlist</a>
    <a href="https://wa.me/<?= e(config('app.whatsapp')) ?>" rel="noopener"><span>◉</span>WhatsApp</a>
  </nav>

  <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
