<?php
declare(strict_types=1);

namespace Veshaal\Controllers;

use Veshaal\NumberService;
use Veshaal\Payments\RazorpayGateway;

final class ApiController
{
    private NumberService $numbers;

    public function __construct()
    {
        $this->numbers = new NumberService();
    }

    public function numbers(): never
    {
        $rows = $this->numbers->search($_GET, 80);
        json_response(['ok' => true, 'count' => count($rows), 'data' => $rows]);
    }

    public function dobSuggestions(): never
    {
        $dob = trim((string) ($_GET['dob'] ?? ''));
        if ($dob === '') {
            json_response(['ok' => false, 'message' => 'Date of birth is required.'], 422);
        }
        $result = $this->numbers->suggestionsForDob($dob, $_GET);
        if (isset($result['error'])) {
            json_response(['ok' => false, 'message' => $result['error']], 422);
        }
        json_response(['ok' => true, 'data' => $result]);
    }

    public function createPayment(): never
    {
        verify_csrf();
        if (config('app.payment_gateway') !== 'razorpay') {
            json_response(['ok' => false, 'message' => 'Online payment is not configured.'], 409);
        }
        $orderNumber = strtoupper(trim((string) ($_POST['order_number'] ?? '')));
        $order = $this->pendingOrder($orderNumber);
        if (!$order) {
            json_response(['ok' => false, 'message' => 'Pending order not found.'], 404);
        }
        $gateway = new RazorpayGateway();
        $remote = $gateway->createOrder($orderNumber, (int) $order['amount']);
        $_SESSION['razorpay_orders'][$orderNumber] = $remote['id'];
        json_response(['ok' => true, 'key' => $gateway->keyId(), 'order' => $remote]);
    }

    public function verifyPayment(): never
    {
        verify_csrf();
        $orderNumber = strtoupper(trim((string) ($_POST['order_number'] ?? '')));
        $gatewayOrderId = (string) ($_POST['razorpay_order_id'] ?? '');
        $paymentId = (string) ($_POST['razorpay_payment_id'] ?? '');
        $signature = (string) ($_POST['razorpay_signature'] ?? '');
        $expectedOrder = (string) ($_SESSION['razorpay_orders'][$orderNumber] ?? '');
        if ($expectedOrder === '' || !hash_equals($expectedOrder, $gatewayOrderId)) {
            json_response(['ok' => false, 'message' => 'Payment order mismatch.'], 422);
        }
        $order = $this->pendingOrder($orderNumber);
        if (!$order) {
            json_response(['ok' => false, 'message' => 'Order is not awaiting payment.'], 409);
        }
        $gateway = new RazorpayGateway();
        if (!$gateway->verify($gatewayOrderId, $paymentId, $signature)) {
            json_response(['ok' => false, 'message' => 'Payment signature could not be verified.'], 422);
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $now = date('Y-m-d H:i:s');
            $pdo->prepare("UPDATE orders SET payment_status = 'paid', payment_reference = ?, order_status = 'verification', updated_at = ? WHERE order_number = ?")
                ->execute([$paymentId, $now, $orderNumber]);
            $pdo->prepare("UPDATE numbers SET status = 'sold', updated_at = ? WHERE id = ?")
                ->execute([$now, $order['number_id']]);
            $pdo->commit();
            unset($_SESSION['razorpay_orders'][$orderNumber]);
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
        json_response(['ok' => true, 'redirect' => url('order/' . $orderNumber)]);
    }

    private function pendingOrder(string $number): ?array
    {
        $stmt = db()->prepare("SELECT * FROM orders WHERE order_number = ? AND payment_status = 'pending' LIMIT 1");
        $stmt->execute([$number]);
        return $stmt->fetch() ?: null;
    }
}

