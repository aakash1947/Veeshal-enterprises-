<?php
declare(strict_types=1);

namespace Veshaal\Controllers;

use Veshaal\NumberService;

final class AdminController
{
    public function login(): void
    {
        if ($this->isAuthenticated()) redirect('admin');
        view('admin/login', ['title' => 'Admin Login'], 'layouts/admin');
    }

    public function authenticate(): void
    {
        verify_csrf();
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $stmt = db()->prepare('SELECT * FROM admins WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        if (!$admin || !password_verify((string) ($_POST['password'] ?? ''), $admin['password_hash'])) {
            flash('error', 'Invalid email or password.');
            redirect('admin/login');
        }
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        $_SESSION['admin_email'] = $admin['email'];
        redirect('admin');
    }

    public function logout(): void
    {
        verify_csrf();
        unset($_SESSION['admin_id'], $_SESSION['admin_email']);
        session_regenerate_id(true);
        redirect('admin/login');
    }

    public function dashboard(): void
    {
        $this->guard();
        $stats = [
            'available' => (int) db()->query("SELECT COUNT(*) FROM numbers WHERE status = 'available'")->fetchColumn(),
            'reserved' => (int) db()->query("SELECT COUNT(*) FROM numbers WHERE status = 'reserved'")->fetchColumn(),
            'orders' => (int) db()->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
            'revenue' => (int) db()->query("SELECT COALESCE(SUM(amount), 0) FROM orders WHERE payment_status IN ('paid','demo')")->fetchColumn(),
        ];
        $orders = db()->query('SELECT o.*, n.mobile_number FROM orders o JOIN numbers n ON n.id = o.number_id ORDER BY o.created_at DESC LIMIT 8')->fetchAll();
        view('admin/dashboard', ['title' => 'Dashboard', 'stats' => $stats, 'orders' => $orders], 'layouts/admin');
    }

    public function inventory(): void
    {
        $this->guard();
        $rows = db()->query('SELECT * FROM numbers ORDER BY created_at DESC, id DESC LIMIT 250')->fetchAll();
        view('admin/inventory', ['title' => 'Inventory', 'numbers' => $rows], 'layouts/admin');
    }

    public function saveInventory(): void
    {
        $this->guard();
        verify_csrf();
        $id = (int) ($_POST['id'] ?? 0);
        $mobile = digits((string) ($_POST['mobile_number'] ?? ''));
        $price = max(0, (int) ($_POST['price'] ?? 0));
        $category = trim((string) ($_POST['category'] ?? 'Unique'));
        $operator = trim((string) ($_POST['operator'] ?? 'Any'));
        $state = trim((string) ($_POST['state'] ?? 'Pan India'));
        $city = trim((string) ($_POST['city'] ?? '')) ?: null;
        $status = (string) ($_POST['status'] ?? 'available');
        $featured = isset($_POST['featured']) ? 1 : 0;
        if (!preg_match('/^[6-9]\d{9}$/', $mobile) || $price < 1 || $category === '') {
            flash('error', 'Enter a valid Indian mobile number, price, and category.');
            redirect('admin/inventory');
        }
        if (!in_array($status, ['available', 'reserved', 'sold', 'hidden'], true)) $status = 'available';
        try {
            if ($id > 0) {
                $stmt = db()->prepare('UPDATE numbers SET mobile_number=?, price=?, category=?, operator=?, state=?, city=?, status=?, featured=?, updated_at=? WHERE id=?');
                $stmt->execute([$mobile, $price, $category, $operator, $state, $city, $status, $featured, date('Y-m-d H:i:s'), $id]);
            } else {
                $stmt = db()->prepare('INSERT INTO numbers (mobile_number, price, category, operator, state, city, status, featured, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$mobile, $price, $category, $operator, $state, $city, $status, $featured, date('Y-m-d H:i:s')]);
            }
            flash('success', 'Inventory saved.');
        } catch (\Throwable) {
            flash('error', 'That mobile number already exists or could not be saved.');
        }
        redirect('admin/inventory');
    }

    public function deleteInventory(): void
    {
        $this->guard();
        verify_csrf();
        $id = (int) ($_POST['id'] ?? 0);
        $used = db()->prepare('SELECT COUNT(*) FROM orders WHERE number_id = ?');
        $used->execute([$id]);
        if ((int) $used->fetchColumn() > 0) {
            db()->prepare("UPDATE numbers SET status='hidden' WHERE id=?")->execute([$id]);
            flash('success', 'Number has order history, so it was hidden instead of deleted.');
        } else {
            db()->prepare('DELETE FROM numbers WHERE id=?')->execute([$id]);
            flash('success', 'Number deleted.');
        }
        redirect('admin/inventory');
    }

    public function orders(): void
    {
        $this->guard();
        $orders = db()->query('SELECT o.*, n.mobile_number, n.category FROM orders o JOIN numbers n ON n.id=o.number_id ORDER BY o.created_at DESC LIMIT 300')->fetchAll();
        view('admin/orders', ['title' => 'Orders', 'orders' => $orders], 'layouts/admin');
    }

    public function updateOrder(): void
    {
        $this->guard();
        verify_csrf();
        $id = (int) ($_POST['id'] ?? 0);
        $status = (string) ($_POST['order_status'] ?? 'verification');
        $allowed = ['pending_payment', 'verification', 'eligibility_issue', 'documents_ready', 'porting', 'activated', 'cancelled', 'refunded'];
        if (!in_array($status, $allowed, true)) $status = 'verification';
        $note = trim((string) ($_POST['admin_note'] ?? ''));
        $stmt = db()->prepare('UPDATE orders SET order_status=?, admin_note=?, updated_at=? WHERE id=?');
        $stmt->execute([$status, $note, date('Y-m-d H:i:s'), $id]);
        if (in_array($status, ['cancelled', 'refunded'], true)) {
            $lookup = db()->prepare('SELECT number_id FROM orders WHERE id=?');
            $lookup->execute([$id]);
            $numberId = (int) $lookup->fetchColumn();
            db()->prepare("UPDATE numbers SET status='available' WHERE id=?")->execute([$numberId]);
        }
        flash('success', 'Order status updated.');
        redirect('admin/orders');
    }

    private function guard(): void
    {
        if (!$this->isAuthenticated()) redirect('admin/login');
    }

    private function isAuthenticated(): bool
    {
        return !empty($_SESSION['admin_id']);
    }
}

