<?php
declare(strict_types=1);

namespace Veshaal\Controllers;

use PDO;
use Veshaal\NumberService;
use Veshaal\Payments\RazorpayGateway;

final class SiteController
{
    private NumberService $numbers;

    public function __construct()
    {
        $this->numbers = new NumberService();
    }

    public function home(): void
    {
        $featured = $this->numbers->search(['sort' => 'featured'], 8);
        $new = $this->numbers->search(['sort' => 'newest'], 6);
        view('pages/home', ['title' => 'Premium & Fancy Mobile Numbers', 'featured' => $featured, 'newNumbers' => $new]);
    }

    public function numbers(): void
    {
        $filters = $_GET;
        $numbers = $this->numbers->search($filters, 80);
        view('pages/numbers', array_merge([
            'title' => 'Browse VIP Mobile Numbers',
            'numbers' => $numbers,
            'filters' => $filters,
        ], $this->numbers->filterOptions()));
    }

    public function numerology(): void
    {
        $result = null;
        $dob = trim((string) ($_GET['dob'] ?? ''));
        if ($dob !== '') {
            $result = $this->numbers->suggestionsForDob($dob, [
                'max_price' => $_GET['max_price'] ?? '',
                'operator' => $_GET['operator'] ?? '',
            ]);
        }
        view('pages/numerology', ['title' => 'DOB Number Finder', 'dob' => $dob, 'result' => $result]);
    }

    public function numberDetail(string $mobile): void
    {
        $number = $this->numbers->findByMobile($mobile);
        if (!$number || $number['status'] === 'hidden') {
            http_response_code(404);
            view('pages/404', ['title' => 'Number not found']);
            return;
        }
        $similar = $this->numbers->search(['category' => $number['category']], 5);
        $similar = array_values(array_filter($similar, static fn(array $row): bool => $row['id'] !== $number['id']));
        view('pages/number-detail', ['title' => $number['formatted'] . ' VIP Number', 'number' => $number, 'similar' => array_slice($similar, 0, 4)]);
    }

    public function cart(): void
    {
        $ids = array_values(array_unique(array_map('intval', $_SESSION['cart'] ?? [])));
        if (isset($_GET['add'])) {
            $id = (int) $_GET['add'];
            $number = $this->numbers->findById($id);
            if ($number && $number['status'] === 'available') {
                $ids[] = $id;
                $_SESSION['cart'] = array_values(array_unique($ids));
                flash('success', 'Number added to your shortlist.');
            }
            redirect('cart');
        }
        if (isset($_GET['remove'])) {
            $remove = (int) $_GET['remove'];
            $_SESSION['cart'] = array_values(array_filter($ids, static fn(int $id): bool => $id !== $remove));
            redirect('cart');
        }
        $items = [];
        foreach ($ids as $id) {
            $number = $this->numbers->findById($id);
            if ($number) $items[] = $number;
        }
        view('pages/cart', ['title' => 'Your Shortlist', 'items' => $items]);
    }

    public function checkout(): void
    {
        $number = $this->numbers->findById((int) ($_GET['number'] ?? 0));
        if (!$number || $number['status'] !== 'available') {
            flash('error', 'That number is no longer available. Please choose another.');
            redirect('numbers');
        }
        view('pages/checkout', ['title' => 'Secure Checkout', 'number' => $number]);
    }

    public function placeOrder(): void
    {
        verify_csrf();
        $number = $this->numbers->findById((int) ($_POST['number_id'] ?? 0));
        $name = trim((string) ($_POST['name'] ?? ''));
        $mobile = digits((string) ($_POST['mobile'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $state = trim((string) ($_POST['state'] ?? ''));
        $operator = trim((string) ($_POST['operator'] ?? ''));
        $accepted = isset($_POST['compliance']);

        $errors = [];
        if (!$number || $number['status'] !== 'available') $errors[] = 'This number is no longer available.';
        if (strlen($name) < 2) $errors[] = 'Please enter your full name.';
        if (!preg_match('/^[6-9]\d{9}$/', $mobile)) $errors[] = 'Enter a valid 10-digit Indian mobile number.';
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if ($state === '' || $operator === '') $errors[] = 'Select your state and preferred operator.';
        if (!$accepted) $errors[] = 'Please accept the operator eligibility and KYC acknowledgement.';
        if ($errors) {
            $_SESSION['_old'] = $_POST;
            flash('error', implode(' ', $errors));
            redirect('checkout?number=' . (int) ($_POST['number_id'] ?? 0));
        }

        $orderNumber = 'VE-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $gateway = (string) config('app.payment_gateway', 'demo');
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $lockSql = config('database.driver') === 'mysql'
                ? "SELECT status FROM numbers WHERE id = ? FOR UPDATE"
                : "SELECT status FROM numbers WHERE id = ?";
            $lock = $pdo->prepare($lockSql);
            $lock->execute([$number['id']]);
            if ($lock->fetchColumn() !== 'available') {
                throw new \RuntimeException('The number was just reserved by another buyer.');
            }
            $now = date('Y-m-d H:i:s');
            $stmt = $pdo->prepare('INSERT INTO orders (order_number, number_id, customer_name, customer_mobile, customer_email, customer_state, preferred_operator, amount, payment_gateway, payment_status, order_status, customer_note, compliance_accepted_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $orderNumber, $number['id'], $name, $mobile, $email ?: null, $state, $operator,
                $number['price'], $gateway, $gateway === 'demo' ? 'demo' : 'pending',
                $gateway === 'demo' ? 'verification' : 'pending_payment', trim((string) ($_POST['note'] ?? '')),
                $now, $now, $now,
            ]);
            $status = $gateway === 'demo' ? 'sold' : 'reserved';
            $pdo->prepare('UPDATE numbers SET status = ?, updated_at = ? WHERE id = ?')->execute([$status, $now, $number['id']]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('error', $e->getMessage());
            redirect('checkout?number=' . $number['id']);
        }

        unset($_SESSION['_old']);
        if ($gateway === 'razorpay') {
            redirect('pay/' . $orderNumber);
        }
        redirect('order/' . $orderNumber);
    }

    public function payment(string $orderNumber): void
    {
        $order = $this->orderByNumber($orderNumber);
        if (!$order || $order['payment_status'] !== 'pending') {
            redirect('order/' . $orderNumber);
        }
        $gateway = new RazorpayGateway();
        $remoteOrder = $gateway->createOrder($orderNumber, (int) $order['amount']);
        $_SESSION['razorpay_orders'][$orderNumber] = $remoteOrder['id'];
        view('pages/payment', [
            'title' => 'Complete Payment', 'order' => $order,
            'razorpayOrder' => $remoteOrder, 'razorpayKey' => $gateway->keyId(),
        ]);
    }

    public function orderSuccess(string $orderNumber): void
    {
        $order = $this->orderByNumber($orderNumber);
        if (!$order) {
            http_response_code(404);
            view('pages/404', ['title' => 'Order not found']);
            return;
        }
        view('pages/order-success', ['title' => 'Order ' . $orderNumber, 'order' => $order]);
    }

    public function track(): void
    {
        $order = null;
        $searched = false;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf();
            $searched = true;
            $number = strtoupper(trim((string) ($_POST['order_number'] ?? '')));
            $mobile = digits((string) ($_POST['mobile'] ?? ''));
            $stmt = db()->prepare('SELECT o.*, n.mobile_number, n.category FROM orders o JOIN numbers n ON n.id = o.number_id WHERE o.order_number = ? AND o.customer_mobile = ? LIMIT 1');
            $stmt->execute([$number, $mobile]);
            $order = $stmt->fetch() ?: null;
        }
        view('pages/track', ['title' => 'Track Your Order', 'order' => $order, 'searched' => $searched]);
    }

    public function howItWorks(): void { view('pages/how-it-works', ['title' => 'How Number Reservation Works']); }
    public function faq(): void { view('pages/faq', ['title' => 'Frequently Asked Questions']); }
    public function legal(): void { view('pages/legal', ['title' => 'Terms, Privacy & Refunds']); }

    public function contact(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf();
            $name = trim((string) ($_POST['name'] ?? ''));
            $mobile = digits((string) ($_POST['mobile'] ?? ''));
            $message = trim((string) ($_POST['message'] ?? ''));
            if (strlen($name) >= 2 && preg_match('/^[6-9]\d{9}$/', $mobile) && strlen($message) >= 10) {
                $stmt = db()->prepare('INSERT INTO enquiries (name, mobile, email, message, created_at) VALUES (?, ?, ?, ?, ?)');
                $stmt->execute([$name, $mobile, trim((string) ($_POST['email'] ?? '')) ?: null, $message, date('Y-m-d H:i:s')]);
                flash('success', 'Thank you. Our number advisor will contact you shortly.');
                redirect('contact');
            }
            flash('error', 'Please complete all required fields correctly.');
        }
        view('pages/contact', ['title' => 'Contact a Number Advisor']);
    }

    private function orderByNumber(string $orderNumber): ?array
    {
        $stmt = db()->prepare('SELECT o.*, n.mobile_number, n.category, n.operator AS inventory_operator, n.state AS inventory_state FROM orders o JOIN numbers n ON n.id = o.number_id WHERE o.order_number = ? LIMIT 1');
        $stmt->execute([strtoupper($orderNumber)]);
        return $stmt->fetch() ?: null;
    }
}
