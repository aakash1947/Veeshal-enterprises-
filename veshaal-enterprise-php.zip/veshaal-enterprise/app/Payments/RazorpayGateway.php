<?php
declare(strict_types=1);

namespace Veshaal\Payments;

use RuntimeException;

final class RazorpayGateway
{
    private string $keyId;
    private string $secret;

    public function __construct()
    {
        $this->keyId = (string) env('RAZORPAY_KEY_ID', '');
        $this->secret = (string) env('RAZORPAY_KEY_SECRET', '');
        if ($this->keyId === '' || $this->secret === '') {
            throw new RuntimeException('Razorpay credentials are not configured.');
        }
    }

    public function createOrder(string $receipt, int $amountRupees): array
    {
        $payload = json_encode([
            'amount' => $amountRupees * 100,
            'currency' => 'INR',
            'receipt' => $receipt,
            'notes' => ['source' => 'Veshaal Enterprise'],
        ]);
        $curl = curl_init('https://api.razorpay.com/v1/orders');
        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_USERPWD => $this->keyId . ':' . $this->secret,
            CURLOPT_TIMEOUT => 20,
        ]);
        $response = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $error = curl_error($curl);
        curl_close($curl);
        $data = json_decode((string) $response, true);
        if ($status < 200 || $status >= 300 || !is_array($data) || empty($data['id'])) {
            throw new RuntimeException('Unable to start payment. ' . ($error ?: 'Please try again.'));
        }
        return $data;
    }

    public function verify(string $razorpayOrderId, string $paymentId, string $signature): bool
    {
        $expected = hash_hmac('sha256', $razorpayOrderId . '|' . $paymentId, $this->secret);
        return hash_equals($expected, $signature);
    }

    public function keyId(): string
    {
        return $this->keyId;
    }
}

