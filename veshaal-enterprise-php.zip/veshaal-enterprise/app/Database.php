<?php
declare(strict_types=1);

namespace Veshaal;

use PDO;
use RuntimeException;

final class Database
{
    private static ?self $instance = null;
    private PDO $pdo;

    private function __construct()
    {
        $driver = (string) config('database.driver', 'sqlite');
        if ($driver === 'mysql') {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                config('database.host'),
                config('database.port'),
                config('database.name')
            );
            $this->pdo = new PDO($dsn, (string) config('database.user'), (string) config('database.password'));
        } else {
            $database = (string) config('database.database', 'storage/veshaal.sqlite');
            $path = str_starts_with($database, '/') ? $database : BASE_PATH . '/' . $database;
            $directory = dirname($path);
            if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
                throw new RuntimeException('Unable to create storage directory.');
            }
            $this->pdo = new PDO('sqlite:' . $path);
            $this->pdo->exec('PRAGMA foreign_keys = ON');
            $this->pdo->exec('PRAGMA journal_mode = WAL');
        }
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    public static function instance(): self
    {
        return self::$instance ??= new self();
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    public function migrateAndSeed(): void
    {
        $driver = (string) config('database.driver', 'sqlite');
        $schema = BASE_PATH . '/database/schema-' . ($driver === 'mysql' ? 'mysql' : 'sqlite') . '.sql';
        if (!is_file($schema)) {
            throw new RuntimeException('Database schema is missing.');
        }
        $this->pdo->exec((string) file_get_contents($schema));

        $count = (int) $this->pdo->query('SELECT COUNT(*) FROM numbers')->fetchColumn();
        if ($count === 0) {
            $seed = require BASE_PATH . '/database/seed.php';
            $stmt = $this->pdo->prepare(
                'INSERT INTO numbers (mobile_number, price, category, operator, state, city, status, featured, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            foreach ($seed as $row) {
                $stmt->execute($row);
            }
        }

        $admins = (int) $this->pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
        if ($admins === 0) {
            $stmt = $this->pdo->prepare('INSERT INTO admins (email, password_hash, created_at) VALUES (?, ?, ?)');
            $stmt->execute([
                strtolower((string) env('ADMIN_EMAIL', 'admin@veshaal.local')),
                password_hash((string) env('ADMIN_PASSWORD', 'ChangeMe!2026'), PASSWORD_DEFAULT),
                date('Y-m-d H:i:s'),
            ]);
        }
    }
}

