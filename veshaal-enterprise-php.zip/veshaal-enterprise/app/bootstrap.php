<?php
declare(strict_types=1);

namespace Veshaal;

use Throwable;

define('BASE_PATH', dirname(__DIR__));

spl_autoload_register(static function (string $class): void {
    $prefix = 'Veshaal\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = BASE_PATH . '/app/' . $relative . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require BASE_PATH . '/app/helpers.php';

load_env(BASE_PATH . '/.env');
date_default_timezone_set('Asia/Kolkata');

if (PHP_SAPI !== 'cli') {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_name('veshaal_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

set_exception_handler(static function (Throwable $e): void {
    http_response_code(500);
    $debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOL);
    if ($debug) {
        header('Content-Type: text/plain; charset=utf-8');
        echo "Application error\n\n" . $e;
        return;
    }
    error_log($e->__toString());
    view('pages/500', ['title' => 'Something went wrong']);
});

Database::instance()->migrateAndSeed();

