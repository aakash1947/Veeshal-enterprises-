<?php
declare(strict_types=1);

use Veshaal\Database;

function load_env(string $path): void
{
    if (!is_file($path)) {
        return;
    }
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        $value = trim($value, "\"'");
        if (!array_key_exists($key, $_ENV)) {
            $_ENV[$key] = $value;
            putenv($key . '=' . $value);
        }
    }
}

function env(string $key, mixed $default = null): mixed
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return match (strtolower((string) $value)) {
        'true' => true,
        'false' => false,
        'null' => null,
        default => $value,
    };
}

function config(string $key, mixed $default = null): mixed
{
    static $cache = [];
    [$file, $item] = array_pad(explode('.', $key, 2), 2, null);
    if (!isset($cache[$file])) {
        $path = BASE_PATH . '/config/' . $file . '.php';
        $cache[$file] = is_file($path) ? require $path : [];
    }
    return $item === null ? $cache[$file] : ($cache[$file][$item] ?? $default);
}

function db(): PDO
{
    return Database::instance()->pdo();
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return base_url() . '/' . ltrim($path, '/');
}

function base_path(): string
{
    // Vercel rewrites requests through /api/index.php while the public site
    // remains rooted at "/". Do not derive "/api" from SCRIPT_NAME there.
    if (env('VERCEL')) {
        return '';
    }

    $configured = trim((string) config('app.url', ''));
    if ($configured !== '') {
        return rtrim((string) (parse_url($configured, PHP_URL_PATH) ?: ''), '/');
    }
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    $directory = rtrim(str_replace('\\', '/', dirname($script)), '/.');
    return $directory === '/' ? '' : $directory;
}

function base_url(): string
{
    $configured = trim((string) config('app.url', ''));
    if ($configured !== '') {
        return rtrim($configured, '/');
    }
    return base_path();
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function view(string $name, array $data = [], string $layout = 'layouts/app'): void
{
    $file = BASE_PATH . '/app/Views/' . $name . '.php';
    if (!is_file($file)) {
        throw new RuntimeException('View not found: ' . $name);
    }
    extract($data, EXTR_SKIP);
    ob_start();
    require $file;
    $content = (string) ob_get_clean();
    if ($layout === '') {
        echo $content;
        return;
    }
    require BASE_PATH . '/app/Views/' . $layout . '.php';
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = (string) ($_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!hash_equals((string) ($_SESSION['_csrf'] ?? ''), $token)) {
        http_response_code(419);
        exit('Your session expired. Please refresh and try again.');
    }
}

function flash(string $key, ?string $value = null): ?string
{
    if ($value !== null) {
        $_SESSION['_flash'][$key] = $value;
        return null;
    }
    $message = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $message;
}

function money(int|float|string $value): string
{
    return '₹' . number_format((float) $value, 0, '.', ',');
}

function digits(string $value): string
{
    return preg_replace('/\D+/', '', $value) ?? '';
}

function digital_root(int $value): int
{
    if ($value === 0) {
        return 0;
    }
    return 1 + (($value - 1) % 9);
}

function number_sum(string $number): int
{
    return array_sum(array_map('intval', str_split(digits($number))));
}

function pattern_score(string $number): int
{
    $number = digits($number);
    $score = 1;
    if ($number === strrev($number)) $score += 4;
    if (preg_match('/(.)\1{2,}/', $number)) $score += 2;
    if (preg_match('/(..)\1{1,}/', $number)) $score += 2;
    if (str_contains($number, '786') || str_contains($number, '108')) $score += 1;
    return min(10, $score);
}

function format_mobile(string $number): string
{
    $n = digits($number);
    return strlen($n) === 10 ? substr($n, 0, 3) . ' ' . substr($n, 3, 3) . ' ' . substr($n, 6) : $n;
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
