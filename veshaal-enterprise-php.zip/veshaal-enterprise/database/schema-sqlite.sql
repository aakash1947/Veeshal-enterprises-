CREATE TABLE IF NOT EXISTS numbers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mobile_number TEXT NOT NULL UNIQUE,
    price INTEGER NOT NULL CHECK(price >= 0),
    category TEXT NOT NULL,
    operator TEXT NOT NULL DEFAULT 'Any',
    state TEXT NOT NULL DEFAULT 'Pan India',
    city TEXT,
    status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','reserved','sold','hidden')),
    featured INTEGER NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT NOT NULL UNIQUE,
    number_id INTEGER NOT NULL,
    customer_name TEXT NOT NULL,
    customer_mobile TEXT NOT NULL,
    customer_email TEXT,
    customer_state TEXT NOT NULL,
    preferred_operator TEXT NOT NULL,
    amount INTEGER NOT NULL,
    payment_gateway TEXT NOT NULL DEFAULT 'demo',
    payment_reference TEXT,
    payment_status TEXT NOT NULL DEFAULT 'pending',
    order_status TEXT NOT NULL DEFAULT 'pending_payment',
    customer_note TEXT,
    admin_note TEXT,
    compliance_accepted_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(number_id) REFERENCES numbers(id)
);

CREATE INDEX IF NOT EXISTS idx_numbers_status_price ON numbers(status, price);
CREATE INDEX IF NOT EXISTS idx_numbers_category ON numbers(category);
CREATE INDEX IF NOT EXISTS idx_orders_mobile ON orders(customer_mobile);

CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS enquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    mobile TEXT NOT NULL,
    email TEXT,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL
);

