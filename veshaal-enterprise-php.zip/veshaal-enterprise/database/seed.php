<?php
$today = date('Y-m-d H:i:s');
$old = date('Y-m-d H:i:s', strtotime('-21 days'));

return [
    ['9898981212', 4500, 'Repeating Pair', 'Airtel', 'Maharashtra', 'Mumbai', 'available', 1, $today],
    ['9000070000', 18000, 'Penta Zero', 'Jio', 'Delhi', 'Delhi', 'available', 1, $today],
    ['8888123456', 12000, 'Counting', 'Vi', 'Uttar Pradesh', 'Lucknow', 'available', 1, $today],
    ['7867869090', 21000, '786 Series', 'Any', 'Pan India', null, 'available', 1, $today],
    ['9112191121', 64000, 'Mirror', 'Airtel', 'Punjab', 'Ludhiana', 'available', 1, $today],
    ['9999902323', 32000, 'Penta Nine', 'Jio', 'Madhya Pradesh', 'Indore', 'available', 1, $today],
    ['8080803434', 9800, 'Repeating Pair', 'BSNL', 'Rajasthan', 'Jaipur', 'available', 0, $today],
    ['9898121212', 7600, 'Ending AB AB', 'Vi', 'Gujarat', 'Ahmedabad', 'available', 0, $today],
    ['9876500000', 26000, 'Penta Zero', 'Airtel', 'Karnataka', 'Bengaluru', 'available', 1, $today],
    ['9123412341', 14000, 'ABC Pattern', 'Jio', 'Telangana', 'Hyderabad', 'available', 0, $old],
    ['9090907777', 17000, 'Tetra Seven', 'Any', 'Pan India', null, 'available', 1, $old],
    ['9810810810', 12500, '108 Series', 'Airtel', 'Delhi', 'Delhi', 'available', 0, $old],
    ['9555520026', 5200, 'Triple Five', 'Vi', 'Maharashtra', 'Pune', 'available', 0, $old],
    ['9300030303', 11500, 'Repeating Pair', 'Jio', 'Chhattisgarh', 'Raipur', 'available', 0, $old],
    ['7999978888', 48000, 'Tetra Combo', 'Airtel', 'Haryana', 'Gurugram', 'available', 1, $old],
    ['9222292222', 72000, 'Tetra Two', 'Jio', 'West Bengal', 'Kolkata', 'available', 1, $old],
    ['7000019477', 8600, 'Birth Year', 'Any', 'Pan India', null, 'available', 0, $old],
    ['9812319999', 15500, 'Tetra Nine', 'Vi', 'Tamil Nadu', 'Chennai', 'available', 0, $old],
    ['8080826262', 6400, 'Ending AB AB', 'BSNL', 'Bihar', 'Patna', 'available', 0, $old],
    ['9899001122', 8800, 'Double Pair', 'Airtel', 'Uttar Pradesh', 'Noida', 'available', 0, $old],
    ['7777010101', 23000, 'Tetra Seven', 'Jio', 'Odisha', 'Bhubaneswar', 'available', 0, $old],
    ['9632100123', 10800, 'Counting', 'Vi', 'Kerala', 'Kochi', 'available', 0, $old],
    ['9898010198', 9500, 'Semi Mirror', 'Any', 'Pan India', null, 'available', 0, $old],
    ['9988776655', 35000, 'Descending Pair', 'Airtel', 'Maharashtra', 'Nagpur', 'available', 1, $old],
];

