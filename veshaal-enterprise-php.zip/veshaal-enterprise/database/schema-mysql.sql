CREATE TABLE IF NOT EXISTS numbers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mobile_number VARCHAR(10) NOT NULL UNIQUE,
    price INT UNSIGNED NOT NULL,
    category VARCHAR(80) NOT NULL,
    operator VARCHAR(30) NOT NULL DEFAULT 'Any',
    state VARCHAR(80) NOT NULL DEFAULT 'Pan India',
    city VARCHAR(80) NULL,
    status ENUM('available','reserved','sold','hidden') NOT NULL DEFAULT 'available',
    featured TINYINT(1) NOT NULL DEFAULT 0,
    added_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status_price(status, price),
    INDEX idx_category(category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(32) NOT NULL UNIQUE,
    number_id BIGINT UNSIGNED NOT NULL,
    customer_name VARCHAR(120) NOT NULL,
    customer_mobile VARCHAR(10) NOT NULL,
    customer_email VARCHAR(190) NULL,
    customer_state VARCHAR(80) NOT NULL,
    preferred_operator VARCHAR(30) NOT NULL,
    amount INT UNSIGNED NOT NULL,
    payment_gateway VARCHAR(30) NOT NULL DEFAULT 'demo',
    payment_reference VARCHAR(120) NULL,
    payment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
    order_status VARCHAR(40) NOT NULL DEFAULT 'pending_payment',
    customer_note TEXT NULL,
    admin_note TEXT NULL,
    compliance_accepted_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_order_number_inventory FOREIGN KEY(number_id) REFERENCES numbers(id),
    INDEX idx_orders_mobile(customer_mobile)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS enquiries (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    mobile VARCHAR(10) NOT NULL,
    email VARCHAR(190) NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

